/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package saes202jegumael2;

import io.jbotsim.core.Topology;
import io.jbotsim.ui.JViewer;

/**
 *
 * @author etd
 */
public class HelloWorld {
    public static void main(String[] args){
        /*
        Topology tp = new Topology();
        new JViewer(tp);
        tp.start();
*/
        new MonApplication();
    }
    
}
