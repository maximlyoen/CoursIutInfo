package recursivite;

/**
 * Exercice Ping-Pong
 */
public class PingPong {
    
    static void ping(int n) {
        // TODO
    }

    static void pong(int n) {
        // TODO
    }

    public static void main(String[] args) {
        // TODO
    }
}
