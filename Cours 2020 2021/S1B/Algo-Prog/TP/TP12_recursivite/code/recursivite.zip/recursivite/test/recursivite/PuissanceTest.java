package recursivite;

import org.junit.Test;

/**
 * Tests du calcul de la puissance.
 */
public class PuissanceTest {

    @Test
    public void testPuissance() {
        // TODO
    }
}
