package recursivite;

import org.junit.Test;

/**
 * Tests de la décomposition binaire d'un entier en base 10.
 */
public class BinaireTest {

    @Test
    public void testChaineBinaire() {
        // TODO
    }
}
