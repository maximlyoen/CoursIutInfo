package recursivite;

/**
 * Calcul de la puissance d'un entier.
 */
class Puissance {
    
    /**
     * Calcul de la puissance d'un entier, avec une complexité logarithmique.
     * 
     * @param a l'entier à élever à la puissance
     * @param n la puissance
     * @return l'entier élevé à la puissance
     */
    static int puissance(int a, int n) {
        // TODO
        return 0;
    }
}
