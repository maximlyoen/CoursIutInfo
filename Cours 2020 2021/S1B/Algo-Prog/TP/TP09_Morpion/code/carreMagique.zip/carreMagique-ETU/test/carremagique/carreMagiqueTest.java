package carremagique;
import org.junit.Test;

/**
 * Tests unitaires du carré magique.
 */
public class carreMagiqueTest {

    @Test
    public void testMagique1() {
    }

    @Test
    public void testMagique2() {
    }

    @Test
    public void testMagique3() {
    }

    @Test
    public void testMagique4() {
    }

    @Test
    public void testMagique5() {
    }

    @Test
    public void testMagique6() {
    }

    @Test
    public void testMagique7() {
    }

    @Test
    public void testMagique8() {
    }
}
