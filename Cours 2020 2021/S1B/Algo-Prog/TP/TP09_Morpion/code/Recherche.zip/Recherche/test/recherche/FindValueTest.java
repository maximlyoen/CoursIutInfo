package recherche;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Tests unitaires de la classe FindValue.
 */
public class FindValueTest {
    
    @Test
    public void testRechercheLineaire() {            
        // TODO
    }

    @Test
    public void testRechercheDichotomique() {
       // TODO
    }
}
