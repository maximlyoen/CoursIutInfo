package distributeurfriandise;

/**
 * Parfums disponibles.
 */
enum Parfum {
    NOISETTE,
    CARAMEL,
    FRAISE, 
    POMME,
    CHOCOLAT,
    RIZ
}
