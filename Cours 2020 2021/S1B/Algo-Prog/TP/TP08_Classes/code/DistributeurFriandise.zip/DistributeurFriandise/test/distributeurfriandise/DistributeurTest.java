package distributeurfriandise;

/**
 * Tests unitaires de la classe Distributeur.
 */
class DistributeurTest {
    
    static void testAjouterBonbon() {
    }

    static void testRetirerBonbon() {
    }

    static void testRetirerBonbons_int() {
    }

    static void testRetirerBonbons_0args() {
    }

    static void testPlein() {
    }

    static void testVide() {
    }

    static void testNombreBonbons() {
    }

    public static void main(String[] args) {
        testAjouterBonbon();
        testRetirerBonbon();
        testRetirerBonbons_int();
        testRetirerBonbons_0args();
        testPlein();
        testVide();
        testNombreBonbons();
    }
}
