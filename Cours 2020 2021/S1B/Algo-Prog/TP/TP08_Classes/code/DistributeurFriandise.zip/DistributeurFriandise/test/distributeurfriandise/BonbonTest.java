package distributeurfriandise;

/**
 * Tests unitaires de la classe Bonbon.
 */
class BonbonTest {
    
    static void testChewingGum() {
    }

    static void testChypresers() {
    }

    static void testTigre() {
    }

    static void testNoisettes() {
    }

    static void testVenus() {
    }

    public static void main(String[] args) {
        testChewingGum();
        testChypresers();
        testTigre();
        testNoisettes();
        testVenus();
    }
}
