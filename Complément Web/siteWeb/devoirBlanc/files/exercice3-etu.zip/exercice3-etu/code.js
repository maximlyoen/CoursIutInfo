
var tabRockers = ["Sid-Viscious","David-Bowie","Mickael-Jackson","Ozzy-Osbourne","Kiss",
"Amy-Winehouse","Elvis-Presley"];



function getAnswer(id){

}


window.onload=function() {	
	creerListes();
}
function creerListes(){	

}


